﻿using UnityEngine;
using System.Collections;

public class EnemigosGeneral : MonoBehaviour {

	public float speed = 5f;
	private float groundRad = 0.2f;
	private bool Right = true;
	private bool onGround = false;
	private Animator anim;
	public Transform CheckGround;
	public LayerMask identGround;
	public Collider2D girar;
	public Collider2D dañar;

	void Start () {
		anim = gameObject.GetComponent<Animator> ();
	}

	// FixUpdate is called once per frame
	//Se utiliza en vez de Update ya que hacemos manipulaciones físicas con los obj
	void FixUpdate () {
		//eje vertical
		onGround = Physics2D.OverlapCircle (CheckGround.position, groundRad, identGround);
		anim.SetBool ("Ground", onGround);
		anim.SetFloat ("Speed", gameObject.GetComponent<Rigidbody2D>().velocity.y);

		//eje horizontal
		//utilizar mover con los colliders -- en progreso
		float mover = Input.GetAxis ("Horizontal");
		Rigidbody2D rb2D = gameObject.GetComponent<Rigidbody2D> ();

		//modificar speed con valor absoluto de mover
		anim.SetFloat("Speed", Mathf.Abs(mover));

		//hacer movimiento
		rb2D.velocity = new Vector2(mover*speed, rb2D.velocity.y);

		//girar, cambiar ese mover por collider
		if(mover > 0 && !Right){
			Girar ();
		}else if(mover < 0 && Right){
			Girar();
		}
	}

	//los personajes tendrán colliders con los cuales girarán
	public void Girar(){
		Right = !Right;

		//Invertimos eje x, es decir, su escala
		//se tiene que hacer una línea por cada cosa, no se puede poner junto
		Vector3 escalaPers = gameObject.transform.localScale;
		escalaPers.x *= -1;
		gameObject.transform.localScale = escalaPers;
	}

	//con los colliders, detectarán si están muriendo o si sólo están dañando
	public void Enemigo(){

	}
}
